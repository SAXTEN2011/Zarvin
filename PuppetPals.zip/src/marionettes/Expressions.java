package marionettes;

public class Expressions {
//	public static final int BROW_NORMAL = 0;
//	public static final int MOUTH_CLOSED = 0;
//	public static final int MOUTH_A = 1;
//	public static final int MOUTH_I = 2;
//	public static final int MOUTH_O = 3;
//	public static final int MOUTH_E = 4;
//	public static final int ANGRY = 1;
//	public static final int SAD = 2;
//	public static final int CONFUSED = 3;
//	public static final int EXCITED = 4;
	public static final int FACING_RIGHT = 10;
	public static final int FACING_LEFT = 11;
	
}
